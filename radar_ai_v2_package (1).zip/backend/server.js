
const express = require('express');
const axios = require('axios');
const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());

// Free public endpoints aggregation
// CoinGecko Free API for AI tokens & Market Cap < $100M filter
app.get('/api/v2/crypto/ai-scanner', async (req, res) => {
    try {
        // Fetch AI category coins from CoinGecko
        const response = await axios.get('https://api.coingecko.com/api/v3/coins/markets', {
            params: {
                vs_currency: 'usd',
                category: 'artificial-intelligence',
                order: 'market_cap_desc',
                per_page: 50,
                page: 1,
                sparkline: false
            }
        });

        // Filter market cap under $100 Million as requested
        const filteredTokens = response.data.filter(coin => coin.market_cap && coin.market_cap < 100000000);

        const formatted = filteredTokens.map(coin => ({
            id: coin.id,
            symbol: coin.symbol.toUpperCase(),
            name: coin.name,
            current_price: coin.current_price,
            market_cap: coin.market_cap,
            total_volume: coin.total_volume,
            fully_diluted_valuation: coin.fully_diluted_valuation || (coin.current_price * coin.max_supply),
            price_change_percentage_24h: coin.price_change_percentage_24h,
            circulating_supply: coin.circulating_supply,
            max_supply: coin.max_supply
        }));

        res.json({
            status: 'success',
            count: formatted.length,
            data: formatted,
            timestamp: new Date().toISOString()
        });
    } catch (error) {
        res.status(500).json({ status: 'error', message: error.message });
    }
});

// DefiLlama Free API for TVL, Fees & Revenue
app.get('/api/v2/fundamental/metrics', async (req, res) => {
    try {
        const protocolsRes = await axios.get('https://api.llama.fi/protocols');
        // Filter AI / Compute / DePIN related protocols
        const aiProtocols = protocolsRes.data.filter(p => 
            p.category && (p.category.toLowerCase().includes('ai') || p.category.toLowerCase().includes('compute') || p.category.toLowerCase().includes('depin'))
        );

        const summary = aiProtocols.map(p => ({
            name: p.name,
            slug: p.slug,
            category: p.category,
            tvl: p.tvl,
            change_1d: p.change_1d,
            change_7d: p.change_7d
        }));

        res.json({
            status: 'success',
            count: summary.length,
            data: summary,
            timestamp: new Date().toISOString()
        });
    } catch (error) {
        res.status(500).json({ status: 'error', message: error.message });
    }
});

// Intelligence & Global Economy RSS / News endpoint aggregator placeholder
app.get('/api/v2/intelligence/feed', async (req, res) => {
    res.json({
        status: 'success',
        data: [
            {
                title: "AI Infrastructure & Decentralized Compute Growth 2026",
                source: "Crypto Research",
                summary: "Demand for decentralized GPU networks continues to surge as LLM training decentralizes.",
                timestamp: new Date().toISOString()
            },
            {
                title: "Global Macro Liquidity & Crypto Market Impact",
                source: "Macro Weekly",
                summary: "Central bank interest rate trajectories point toward risk-on asset favoring high-beta crypto sectors.",
                timestamp: new Date().toISOString()
            }
        ]
    });
});

app.listen(PORT, () => {
    console.log(`RADAR AI V2 Backend running on port ${PORT}`);
});
