# PANDUAN PEMASANGAN & PENGGUNAAN RADAR AI V2 (UNTUK PENGGUNA ANDROID)

Aplikasi **RADAR AI V2** dirancang agar Anda dapat langsung memantau pasar token AI, fundamental, dan berita intelijen secara instan tanpa harus mengerti pemrograman atau membangun server sendiri.

---

### LANGKAH 1: Menjalankan Server Backend Pemantauan (Gratis di Cloud)
Server ini bertugas menarik data resmi dari CoinGecko & DefiLlama secara otomatis dan aman (tanpa membebani baterai HP Android Anda).

1. Buka [Render.com](https://render.com) atau [Railway.app](https://railway.app) (gratis).
2. Unggah folder `backend` yang ada di dalam arsip ZIP ini.
3. Gunakan perintah *Start Command*: `npm start`.
4. Setelah aktif, Anda akan mendapatkan URL Backend Anda (contoh: `https://radar-ai-v2.onrender.com`).

---

### LANGKAH 2: Mengakses Dashboard di HP Android
Karena Anda tidak memerlukan instalasi file APK yang rumit, Anda dapat langsung mengakses antarmuka RADAR AI V2 melalui *Web App / PWA* yang ringan atau langsung menggunakan browser HP Anda:

1. Buka browser (Chrome / Brave) di HP Android Anda.
2. Masukkan URL Backend Anda ditambah endpoint `/api/v2/crypto/ai-scanner` untuk melihat data langsung token AI dengan Market Cap < $100 Juta.
3. **Fitur Watchlist & Notifikasi:** Sistem berjalan otomatis di server cloud 24/7. Anda dapat menghubungkan webhooks gratis ke Telegram bot pribadi Anda untuk menerima notifikasi otomatis saat terjadi lonjakan volume atau perubahan harga signifikan.

---

### FITUR UTAMA DALAM SISTEM:
- **Crypto Scanner:** Menyaring token AI dengan valuasi di bawah $100 Juta secara *real-time*.
- **Fundamental & TVL:** Memantau TVL protokol AI & DePIN melalui DefiLlama.
- **Efisiensi Baterai:** Tidak ada *polling* berat di HP Anda karena seluruh kalkulasi dijalankan di cloud server.
- **Keamanan:** Kredensial dan API Key aman di sisi server.
